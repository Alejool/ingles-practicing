# Ruta B1 → B2

App instalable (PWA) para preparar exámenes de certificación de inglés B1/B2
—Cambridge B1 Preliminary y B2 First, IELTS, TOEFL, Aptis, Linguaskill—
hecha con **Astro 7 + TypeScript**, con API propia y **PostgreSQL**.

- **Todo el material es libre y sin cuenta**: diagnóstico, plan de 24 semanas, 18 unidades de
  gramática, 154 tarjetas con repetición espaciada, Use of English, writing, speaking, lectura y
  simulacro. Funciona sin conexión.
- **La clave de DeepSeek nunca llega al navegador.** Las correcciones pasan por `/api/ai/chat`,
  que compone los prompts en el servidor y aplica cuotas.
- **Cuenta solo cuando hace falta**: se estudia sin registrarse; al agotar el cupo de prueba de
  correcciones se entra con un enlace por correo, sin contraseña. La cuenta además sincroniza el
  progreso entre dispositivos.

## Arrancar

```bash
bash start.sh
```

Eso construye el front, levanta la API, la base de datos y un buzón de correo, aplica el esquema
y espera a que todo responda. La primera vez tarda un par de minutos; después, segundos.

```
App      http://localhost:8080
Correo   http://localhost:8025   ← aquí llegan los enlaces para entrar
```

Lo único que hay que poner a mano es la clave de DeepSeek: ábrela en `.env`
(`DEEPSEEK_API_KEY=sk-…`, se saca en <https://platform.deepseek.com/api_keys>) y
`bash start.sh restart`. Sin ella la app funciona entera menos las correcciones con IA.

`start.sh` crea el `.env` la primera vez y genera solo la contraseña de la base, el `IP_PEPPER`
y el `ADMIN_TOKEN`.

| Comando | Qué hace |
|---|---|
| `bash start.sh` | levanta todo |
| `bash start.sh logs` | logs en vivo |
| `bash start.sh stop` | parar, conservando los datos |
| `bash start.sh restart` | reconstruir tras cambiar código o `.env` |
| `bash start.sh admin` | llamadas y tokens gastados |
| `bash start.sh psql` | consola SQL |
| `bash start.sh test` | prueba de humo de todo el stack |
| `bash start.sh reset` | borrar la base y empezar de cero |

### Comprobar que todo funciona

```bash
bash start.sh test
```

28 comprobaciones contra el stack que acabas de levantar: que el front se sirve entero, que
**no hay ninguna clave en el bundle del navegador**, que el service worker no cachea `/api/`,
que una corrección real llega por streaming y sus tokens quedan contabilizados, que el cupo
anónimo se agota con el mensaje correcto, que el enlace mágico entra y no vale dos veces,
que la cuota sube al iniciar sesión, que el progreso sincroniza y detecta conflictos de versión,
y que el endpoint de administración rechaza un token incorrecto. Al terminar borra las cuentas
que creó (`@smoke.test`).

Gasta unas 6 llamadas reales a DeepSeek. Para no gastarlas: `SMOKE_SKIP_AI=1 bash start.sh test`.

### Sin Docker

```bash
npm install
cp .env.docker.example .env      # rellena DATABASE_URL y DEEPSEEK_API_KEY
npm run build                    # astro check + astro build → dist/
npm start                        # servidor en :8080, aplica el esquema al arrancar
```

Para trabajar en el front: `npm run dev` (Astro solo, sin API ni service worker).

---

## Cómo está montado

```
src/                      front (Astro, estático)
├── data/*.ts             todo el contenido del curso, tipado
├── components/views/     el markup de cada módulo
└── scripts/
    ├── api.ts            cliente de la API propia (device id, sesión, cuota)
    ├── ai.ts             correcciones: servidor compartido o clave propia
    ├── sync.ts           progreso: fusión y subida
    └── views/*.ts        lógica de cada módulo

shared/prompts.ts         los prompts, compartidos por servidor y cliente
db/schema.sql             esquema de PostgreSQL

server/index.mts          servidor: sirve dist/ y enruta las funciones
Dockerfile                imagen única (front construido + API)
docker-compose.yml        app + postgres + mailpit
start.sh                  el comando de arriba

netlify/functions/
├── ai-chat.mts           POST /api/ai/chat        proxy + cuota + contabilidad
├── auth-request.mts      POST /api/auth/request   manda el enlace mágico
├── auth-verify.mts       GET  /api/auth/verify    consume el enlace y crea sesión
├── auth-session.mts      GET/POST /api/auth/session   quién soy / cerrar sesión
├── progress.mts          GET/PUT /api/progress    progreso sincronizado
├── quota.mts             GET  /api/quota
├── admin.mts             GET/POST /api/admin      uso, gasto y migración
└── _*.mts                http, db, auth, cuotas y correo
```

## El modelo de seguridad, en corto

**La clave.** Vive solo en `DEEPSEEK_API_KEY`, una variable de entorno del sitio. El navegador
nunca la ve ni puede pedirla. En el bundle del front no hay ningún secreto: compruébalo con
`grep -r "sk-" dist/`.

**El endpoint no es un chatbot libre.** El cliente manda `{kind, payload}` —por ejemplo
`kind: "writing"` con la tarea y el texto—, y quien redacta las instrucciones del modelo es
`shared/prompts.ts` en el servidor. No se puede inyectar un system prompt propio ni usar la API
para otra cosa. Además se validan tipo, tamaño (24 KB por mensaje, 12 turnos) y modelo.

**Tres barreras de gasto**, en `_quota.mts`:

| Barrera | Qué limita | Variable |
|---|---|---|
| Ritmo | llamadas por minuto de un dispositivo o IP | `QUOTA_PER_MINUTE` |
| Persona sin cuenta | correcciones totales, por dispositivo **y** por IP | `QUOTA_ANON_LIFETIME` |
| Persona con cuenta | por día y por mes | `QUOTA_USER_DAILY`, `QUOTA_USER_MONTHLY` |
| Despliegue | tope diario de toda la app | `QUOTA_GLOBAL_DAILY` |

El cupo anónimo se cuenta por dispositivo **y** por IP, y manda el mayor de los dos: borrar el
localStorage no devuelve las llamadas gastadas. El tope global es el que garantiza que la factura
tiene techo pase lo que pase; cuando se alcanza, la app lo dice y sigue funcionando todo lo demás.

**Contabilidad real.** Cada llamada deja una fila en `ai_usage` con los tokens que devolvió
DeepSeek, así que `/api/admin` te dice exactamente cuánto se está gastando y en qué módulos.
La llamada se apunta *antes* de empezar a transmitir: cortar la conexión a mitad no la hace gratis.

**Sesiones.** Enlace mágico de un solo uso, 15 minutos de vida. De los tokens solo se guarda el
SHA-256, tanto del enlace como de la sesión. No hay contraseñas que filtrar. `/api/auth/request`
responde siempre lo mismo exista o no la cuenta, para que nadie descubra qué correos hay
registrados. Hay límite de enlaces por correo y por IP.

**Datos.** Se guarda el correo, el progreso y una fila por llamada con la IP **hasheada con
pimienta** (`IP_PEPPER`), nunca en claro. Nada más: ni analítica, ni perfiles, ni terceros.

**Escape sin servidor.** Quien quiera puede poner su propia clave de DeepSeek en Ajustes: entonces
las peticiones salen de su navegador, no gastan tu cuota y no pasan por tu servidor.

## Desplegar fuera de tu máquina

Hay dos caminos y el mismo código sirve para los dos: las funciones son handlers estándar
(`Request` → `Response`), y `server/index.mts` se limita a enrutarlas.

### A. Docker en un servidor

```bash
git clone … && cd ruta-b1b2
bash start.sh
```

Después ponlo detrás de nginx, Traefik o Caddy con TLS, y en `.env`:

```
APP_URL=https://ruta.tudominio.com
ALLOWED_ORIGINS=https://ruta.tudominio.com
TRUST_PROXY=true
MAIL_PROVIDER=resend
RESEND_API_KEY=re_…
MAIL_FROM=Ruta B1→B2 <acceso@tudominio.com>
```

**`TRUST_PROXY=true` es obligatorio detrás de un proxy inverso**: sin eso todas las visitas
llegan con la IP del proxy, comparten el mismo cupo anónimo y la primera persona se lo gasta
para todas. Y quita el servicio `mailpit` del compose: es un buzón de desarrollo, no manda
correos de verdad.

### B. Netlify + Neon

Crea la base en [Neon](https://neon.tech), pon `DATABASE_URL`, y `netlify deploy --prod`.
`netlify.toml` ya trae el build, las funciones y las cabeceras. El driver se elige solo:
si `DATABASE_URL` apunta a Neon usa HTTP, y si no, `pg` con pool. Se puede forzar con
`DB_DRIVER=neon|pg`.

## Puesta en marcha manual de la base

### 1. Base de datos

Crea una en [Neon](https://neon.tech) (el plan gratis sobra) y copia la cadena de conexión en
`DATABASE_URL`. Después aplica el esquema, de una de estas dos formas:

```bash
psql "$DATABASE_URL" -f db/schema.sql
# o, ya desplegado:
curl -X POST "https://tu-sitio.netlify.app/api/admin?token=$ADMIN_TOKEN&op=schema"
```

`db/schema.sql` es idempotente: se puede lanzar las veces que haga falta.

### 2. Correo

Cuatro proveedores: `resend`, `postmark`, `smtp` y `log`.

- **Docker** usa `smtp` contra Mailpit: los enlaces se ven en <http://localhost:8025> y no sale
  ningún correo de tu máquina.
- **Producción**: `resend` con `RESEND_API_KEY` es lo más rápido ([resend.com](https://resend.com),
  3.000 correos gratis al mes). `smtp` sirve para cualquier servidor propio.
- **`log`** no envía nada y escribe el enlace en los logs. Solo desarrollo.

Verifica tu dominio en el proveedor y pon `MAIL_FROM` con una dirección de ese dominio, o los
correos acabarán en spam.

### 3. Comprobar que está bien

```bash
grep -r "sk-" dist/ || echo "sin claves en el bundle ✓"
curl -s http://localhost:8080/healthz | jq         # base de datos viva
curl -s http://localhost:8080/api/quota | jq       # cuota anónima
curl -s "http://localhost:8080/api/admin?token=malo"   # debe dar 403
bash start.sh admin                                 # uso y gasto
```

## Vigilar el gasto

```bash
bash start.sh admin
# o, desplegado:  curl -s "https://tu-sitio/api/admin?token=$ADMIN_TOKEN" | jq
```

Devuelve llamadas y tokens por día, por tipo de módulo y el ranking del mes. Para subirle la cuota
a alguien concreto sin tocar el `.env`:

```sql
-- bash start.sh psql
update users set daily_bonus = 50 where email = 'quien@sea.com';
```

Y para cortar a alguien: `update users set blocked = true where email = '…';`

## Actualizaciones

Al desplegar cambios, sube `CACHE_VERSION` en `public/sw.js` (`ruta-b1b2-v3`, etc.) y `APP_VERSION`
en `src/scripts/views/settings.ts`. La app detecta la versión nueva y ofrece un botón «Actualizar».

El service worker **nunca** cachea `/api/*`: si lo tocas, mantén esa exclusión o la app se quedará
con una respuesta de sesión antigua pegada.

## Añadir contenido

Todo el curso está en `src/data/*.ts` con interfaces en `types.ts`. Una unidad de gramática nueva es
un objeto más en `grammar.ts`; una semana, un objeto en `plan.ts`. La lógica de las vistas no se
toca. `npm run build` corre `astro check` antes de compilar, así que un campo mal puesto rompe el
build en vez de fallar en producción.

## Sobre `server/laravel/`

Es el proxy de la versión anterior, cuando la clave iba en el cliente y no había cuotas. Ya no se
usa: la API de `netlify/functions/` lo sustituye entera. Puedes borrar esa carpeta.

## TypeScript

`tsconfig.json` extiende `astro/tsconfigs/base` con `strictNullChecks` y `noImplicitAny`
desactivados: las vistas vienen de un port de JavaScript. Lo que sí está tipado del todo es
`src/data/`, `shared/prompts.ts` y todo `netlify/functions/`, que es donde importa.
