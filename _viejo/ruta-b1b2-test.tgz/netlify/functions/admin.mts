/**
 * GET  /api/admin?token=…            · uso y gasto de los últimos días
 * POST /api/admin?token=…&op=schema  · crea o actualiza las tablas
 *
 * Protegido por ADMIN_TOKEN. Sin esa variable el endpoint no existe.
 */

import { preflight, json, fail, ApiError } from "./_http.mts";
import { q, migrate } from "./_db.mts";
import { readFile } from "node:fs/promises";
import { join } from "node:path";

function assertAdmin(req: Request): void {
  const expected = process.env.ADMIN_TOKEN || "";
  if (!expected) throw new ApiError(404, "not_found", "No disponible.");
  const url = new URL(req.url);
  const given = url.searchParams.get("token") || (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (given !== expected) throw new ApiError(403, "forbidden", "Token de administración incorrecto.");
}

/** El bundle de Netlify mueve los archivos: se prueban las dos rutas posibles. */
async function readSchema(): Promise<string> {
  const candidates = [new URL("../../db/schema.sql", import.meta.url), join(process.cwd(), "db/schema.sql")];
  for (const c of candidates) {
    try { return await readFile(c as any, "utf8"); } catch { /* siguiente */ }
  }
  throw new ApiError(500, "schema_missing", "No se encontró db/schema.sql en el despliegue.");
}

export default async (req: Request): Promise<Response> => {
  const pre = preflight(req);
  if (pre) return pre;
  try {
    assertAdmin(req);

    if (req.method === "POST" && new URL(req.url).searchParams.get("op") === "schema") {
      const applied = await migrate(await readSchema());
      return json(req, { ok: true, message: `Esquema aplicado (${applied} sentencias).` });
    }

    if (req.method === "POST" && new URL(req.url).searchParams.get("op") === "cleanup-test") {
      // Borra lo que dejan las pruebas: cuentas @smoke.test y su consumo.
      const gone = await q<{ email: string }>(
        `delete from users where email like '%@smoke.test' returning email`, []);
      await q(`delete from ai_usage where kind = 'test' and user_id is null and device_id like 'smoke-%'`, []);
      await q(`delete from ai_usage where device_id like 'smoke-%'`, []);
      await q(`delete from login_tokens where email like '%@smoke.test'`, []);
      return json(req, { ok: true, borrados: gone.length });
    }

    const days = await q(
      `select day::text,
              count(*)::int                                as llamadas,
              count(distinct coalesce(user_id::text, device_id)) as personas,
              sum(prompt_tokens)::int                      as tokens_entrada,
              sum(completion_tokens)::int                  as tokens_salida,
              count(*) filter (where user_id is null)::int as anonimas
         from ai_usage
        where day > current_date - 30
        group by day
        order by day desc`, []);

    const byKind = await q(
      `select kind, count(*)::int as llamadas, sum(prompt_tokens + completion_tokens)::int as tokens
         from ai_usage where day > current_date - 30 group by kind order by llamadas desc`, []);

    const top = await q(
      `select u.email, count(*)::int as llamadas, sum(a.prompt_tokens + a.completion_tokens)::int as tokens
         from ai_usage a join users u on u.id = a.user_id
        where a.created_at >= date_trunc('month', now())
        group by u.email order by llamadas desc limit 20`, []);

    const totals = await q(
      `select count(*)::int as usuarios,
              (select count(*)::int from ai_usage where day = current_date) as hoy,
              (select coalesce(sum(prompt_tokens + completion_tokens),0)::int from ai_usage
                where created_at >= date_trunc('month', now())) as tokens_mes
         from users`, []);

    return json(req, { totales: totals[0] ?? null, por_dia: days, por_tipo: byKind, top_del_mes: top });
  } catch (e) {
    return fail(req, e);
  }
};

export const config = { path: "/api/admin" };
